export type OpenAIResponsesModelId = string
